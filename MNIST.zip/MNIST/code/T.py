# -*- coding: utf-8 -*-
"""
Created on Wed Apr 15 08:29:52 2020

@author: 王俪晔
"""

import os
import numpy as np
import operator


IMAGE_ROW = 28
IMAGE_COL = 28
IMAGE_SIZE = 28*28

def read_head(filename):
    print('读取：',os.path.basename(filename))
    
    with open(filename,'rb') as pf:
        #获取magic number
        data = pf.read(4)
        magic_num = int.from_bytes(data,byteorder='big')#bytes数据大尾端模式转换为int型

        #获取dimension长度
        dimension = magic_num & 0xff
        
    return dimension



def read_image(filename,head_len,offset,amount):
    image_mat=np.zeros((amount,IMAGE_SIZE),dtype=np.uint8)
    
    with open(filename,'rb') as pf:
        #移动偏移量
        pf.seek(head_len+IMAGE_SIZE*offset) 
        
        for ind in range(amount):
            image = np.zeros((1,IMAGE_SIZE),dtype=np.uint8)#创建一个1，28x28的array
            for row in range(IMAGE_SIZE):#处理28行数据，
                data = pf.read(1)#读单个像素
                pix = int.from_bytes(data,byteorder='big')
                #简单滤波
                if pix >45:image[0][row] = 1
                
            image_mat[ind,:]=image
    
    return image_mat


def read_label(filename,head_len,offset,amount):
    label_list=[]
    
    with open(filename,'rb') as pf:
        #移动偏移量
        pf.seek(head_len+offset) 
    
        for ind in range(amount):
            data = pf.read(1)
            label = int.from_bytes(data,byteorder='big')
            label_list.append(label)
    
    return label_list



def read_image_label_vector(image_file,label_file,offset,amount):
    
    #读image
    image_dim = read_head(image_file)
    image_head_len = 4*(image_dim+1)
    image_ = read_image(image_file,image_head_len,offset,amount)
    
    #读label
    label_dim = read_head(label_file)
    label_head_len = 4*(label_dim+1)
    label_ = read_label(label_file,label_head_len,offset,amount)
    
    return image_,label_


def knn_classify(test_data, train_dataset, train_label, k):
    train_dataset_amount = train_dataset.shape[0]#获得训练样本的的个数

    #统一维度
    test_rep_mat =  np.tile(test_data, (train_dataset_amount,1))
    diff_mat = test_rep_mat - train_dataset

    #平方
    sq_diff_mat = diff_mat**2

    #相加
    sq_dist = sq_diff_mat.sum(axis=1)

    #开方，得到欧式距离
    distance = sq_dist**0.5
    
    #索引排序
    dist_index = distance.argsort()


    class_count={}
    for i in range(k):
        label = train_label[dist_index[i]]

        #投票法
        class_count[label] = class_count.get(label,0) + 1

    #降序排列
    class_count_list = sorted(class_count.items(), key=operator.itemgetter(1), reverse=True)

    return class_count_list[0][0]


if __name__ == '__main__':
    train_image_file = '../train-images.idx3-ubyte'
    train_label_file = '../train-labels.idx1-ubyte'
    test_image_file = '../t10k-images.idx3-ubyte'
    test_label_file = '../t10k-labels.idx1-ubyte'
    
    train_image_mat, train_label_list  = read_image_label_vector(train_image_file,train_label_file,0,6000)#读取第0张后的6000张图片为训练集
    test_image_mat, test_label_list  = read_image_label_vector(test_image_file,test_label_file,500,500)#读取第500张图片后的500张图片为测试集
    
    err_count = 0.0
    for i in range(len(test_image_mat)):
        class_result = knn_classify(test_image_mat[i], train_image_mat, train_label_list, 3)
        
        if(class_result != test_label_list[i]):
            print( "第 %d 个数字, 分类值: %d, 实际值: %d" % (i,class_result, test_label_list[i]),end=' ')
            print()
            err_count += 1.0
    
    print( "\n总错误数: %d" % err_count)
    print( "正确率率: %2.2f%%" % (100.0 - 100.0*err_count/len(test_image_mat)))















